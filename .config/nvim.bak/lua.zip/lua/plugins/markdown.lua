return {
  {
    "preservim/vim-markdown",
    require = { "godlygeek/tabular" },
  },
}
